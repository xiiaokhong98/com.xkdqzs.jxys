template="tool"
name="小康大全助手"
